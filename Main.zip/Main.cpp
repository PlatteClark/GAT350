#include "Engine.h" 
#include <iostream> 

float points[] = {
	 -1.0f,  1.0f, 0.0f,
	 1.0f,  1.0f, 0.0f,
	-1.0f,  -1.0f, 0.0f,

	1.0f,  -1.0f, 0.0f,
    -1.0f,  -1.0f, 0.0f,
	 1.0f,  1.0f, 0.0f

};

glm::vec3 colors[] = {
	{0, 0, 1},
	{1, 0, 1},
	{0, 1, 0},
	{0, 0, 1},
	{0, 1, 1},
	{1, 1, 1}
};

glm::vec2 texcoords[] = {
	{ 1, 0 },
	{ 0, 0 },
	{ 1, 1 },
	{ 0, 1 },
	{ 1, 1 },
	{ 0, 0 }
};

int main(int argc, char** argv)
{
	LOG("Application Started...");
	squampernaut::InitializeMemory();

	squampernaut::SetFilePath("../Assets");

	squampernaut::Engine::Instance().Initialize();
	squampernaut::Engine::Instance().Register();

	LOG("Engine Initialized...");

	squampernaut::g_renderer.CreateWindow("Game", 800, 600, false);

	LOG("Window Created...");

	// create vertex buffer
	GLuint pvbo = 0;
	glGenBuffers(1, &pvbo);
	glBindBuffer(GL_ARRAY_BUFFER, pvbo);
	glBufferData(GL_ARRAY_BUFFER, 18 * sizeof(float), points, GL_STATIC_DRAW);

	// create color vertex buffer
	GLuint cvbo = 0;
	glGenBuffers(1, &cvbo);
	glBindBuffer(GL_ARRAY_BUFFER, cvbo);
	glBufferData(GL_ARRAY_BUFFER, 6 * sizeof(glm::vec3), colors, GL_STATIC_DRAW);

	GLuint tvbo = 0;
	glGenBuffers(1, &tvbo);
	glBindBuffer(GL_ARRAY_BUFFER, tvbo);
	glBufferData(GL_ARRAY_BUFFER, 6 * sizeof(glm::vec2), texcoords, GL_STATIC_DRAW);
	
	// create vertex array
	GLuint vao = 0;
	glGenVertexArrays(1, &vao);
	glBindVertexArray(vao);

	glEnableVertexAttribArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, pvbo);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, NULL);

	glEnableVertexAttribArray(1);
	glBindBuffer(GL_ARRAY_BUFFER, cvbo);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, NULL);

	glEnableVertexAttribArray(2);
	glBindBuffer(GL_ARRAY_BUFFER, tvbo);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 0, NULL);

	// create program
	//std::shared_ptr<squampernaut::Program> program = squampernaut::g_resources.Get<squampernaut::Program>("Shaders/basic.prog");
	//program->Link();
	//program->Use();

	// create material 
	std::shared_ptr<squampernaut::Material> material = squampernaut::g_resources.Get<squampernaut::Material>("Materials/box.mtrl");
	material->Bind();

	glm::mat4 mx{ 1 };

	/*program->SetUniform("scale", std::sin(squampernaut::g_time.time * 3));
	program->SetUniform("transform", mx);*/



	bool quit = false;
	while (!quit)
	{
		squampernaut::Engine::Instance().Update();

		if (squampernaut::g_inputSystem.GetKeyState(squampernaut::key_escape) == squampernaut::InputSystem::KeyState::Pressed) quit = true;
	
		mx = glm::eulerAngleXYZ(0.0f, 0.0f, squampernaut::g_time.time);

		material->GetProgram()->SetUniform("tint", glm::vec3{ 1, 0, 0 });
		material->GetProgram()->SetUniform("scale", 0.5f);

		//material->GetProgram()->SetUniform("scale", std::sin(squampernaut::g_time.time * 3));
		material->GetProgram()->SetUniform("transform", mx);

		squampernaut::g_renderer.BeginFrame();

		glDrawArrays(GL_TRIANGLES, 0, 6);

		squampernaut::g_renderer.EndFrame();
	}

	squampernaut::Engine::Instance().Shutdown();
	return 0;
}